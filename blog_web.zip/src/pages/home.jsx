﻿export default function Home() {
    return <h2>Ласкаво просимо до Технологічного блогу!</h2>;
}