﻿export default function About() {
    return <h2>Це блог про найсучасніші технології.</h2>;
}