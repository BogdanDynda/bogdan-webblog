﻿import { Outlet, NavLink, useNavigation } from "react-router-dom";
import "../css/root.css";

export default function Root() {
    const navigation = useNavigation();

    return (
        <>
            <div id="sidebar">
                <h1>Dynda Blog</h1>
                <nav>
                    <NavLink to="/">Головна</NavLink>
                    <NavLink to="/about">Про нас</NavLink>
                    <NavLink to="/articles">Статті</NavLink>
                    <NavLink to="/resources">Ресурси</NavLink>
                </nav>
            </div>

            {navigation.state === "loading" && (
                <div style={{ padding: "10px", background: "yellow", color: "black" }}>
                    Завантаження...
                </div>
            )}

            <div id="detail">
                <Outlet />
            </div>
        </>
    );
}
