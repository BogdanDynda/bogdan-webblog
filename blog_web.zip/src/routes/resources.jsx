﻿import { Link, useLoaderData } from "react-router-dom";
import SearchForm from "../components/SearchForm";

export default function ResourcesPage() {
    const { resources, query } = useLoaderData();

    return (
        <div>
            <h2>Список ресурсів</h2>

            <SearchForm />

            <p>Пошук: <b>{query || "—"}</b></p>

            <ul>
                {resources.map((item) => (
                    <li key={item.id}>
                        <Link to={`/resources/${item.id}`}>
                            {item.title}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}
